#include "functions.h"
#include "string.h"
#include "Arduino.h"

char* charToHexadecimal(char* value) {
  int len = sizeof(value)/sizeof(value[0]);
  char* hex_str = (char*)malloc(2 * len + 1); // Each character becomes 2 hexadecimal characters
  if (hex_str != NULL) {
    for (int i = 0; i < len; i++) {
        sprintf(hex_str + 2 * i, "%X", value[i]);
    }
  hex_str[2 * len] = '\0';
  } else {
    printf("Memory allocation failed.\n");
  }
  return hex_str;
}

char* shortToHexadecimal(short int value){
  if (value >= -32768 && value <= 32767) {
    char* hex_txt = (char*)malloc(5); // 4 characters for the hex value and 1 for the null terminator
    sprintf(hex_txt, "%04X", value);
    return hex_txt;
  } else {
        // Handle the case where the input is out of range
    printf("Inavlid Value\n");
    return 0;
  }
}

char hexadecimalToBinary(char* value)
{
      //Skips "0x" if present at beggining of Hex string
    size_t i = (value[1] == 'x' || value[1] == 'X')? 2 : 0;

    char* result;
 
    while (value[i]) {
 
        switch (value[i]) {
        case '0':
            strcpy(result,"0000");
            break;
        case '1':
            strcat(result,"0001");
            break;
        case '2':
            strcat(result,"0010");
            break;
        case '3':
            strcat(result,"0011");
            break;
        case '4':
            strcat(result,"0100");
            break;
        case '5':
            strcat(result,"0101");
            break;
        case '6':
            strcat(result,"0110");
            break;
        case '7':
            strcat(result,"0111");
            break;
        case '8':
            strcat(result,"1000");
            break;
        case '9':
            strcat(result,"1001");
            break;
        case 'A':
        case 'a':
            strcat(result,"1010");
            break;
        case 'B':
        case 'b':
            strcat(result,"1011");
            break;
        case 'C':
        case 'c':
            strcat(result,"1100");
            break;
        case 'D':
        case 'd':
            strcat(result,"1101");
            break;
        case 'E':
        case 'e':
            strcat(result,"1110");
            break;
        case 'F':
        case 'f':
            strcat(result,"1111");
            break;
        default:
            printf("\nInvalid hexadecimal digit %c", value[i]);
        }
        i++;
    }
}