#ifndef udf_h
#define udf_h

typedef struct udf
{
    short int sensorID[2] = {1,2} ;
    char* sensorName[2] = {"Accelerometer(G)" , "Gyroscope(dps)"};
    short int eventSize[2] = {6,6};
    char* parseFormat[2] = {"short int","short int"};
    char* axisNames[2] = {"x,y,z" , "x,y,z"};
    char* scalingFactor[2] = {"0.000488281250000","0.061035156250000"};
}udf;

extern char *nibbleTable[] =
{
    "0000",
    "0001",
    "0010",
    "0011",
    "0100",
    "0101",
    "0110",
    "0111",
    "1000",
    "1001",
    "1010",
    "1011",
    "1100",
    "1101",
    "1110",
    "1111"
};

#endif

/*
    1) create a datatype per the UDF - Variable Schema v1.0
    2) convert all the values in hexadecimal 
    3) set the values in the correct order as per the program 
    4) convert the hex to binary
    5) send the data in binary form 
    6) reverse the procedure on the server side and dispaly the data 
*/