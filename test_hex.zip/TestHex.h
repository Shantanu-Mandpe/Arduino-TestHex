#ifndef TestHex_h
#define TestHex_h

#include "Arduino.h"

class TestHex
{
  public:
    TestHex(short int id);
    void convert(short int sensorValue[]);
  private:
    short int _id;
};

#endif