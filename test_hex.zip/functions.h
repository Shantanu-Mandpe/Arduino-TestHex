#ifndef functions_h
#define functions_h

extern char* charToHexadecimal(char* value);
extern char* shortToHexadecimal(short int value);
extern char hexadecimalToBinary(char* value);

#endif