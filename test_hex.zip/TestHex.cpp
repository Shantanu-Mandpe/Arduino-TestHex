#include "Arduino.h"
#include "TestHex.h"


#include "udf.h"
#include "functions.h"

TestHex::TestHex(short int id) 
{
  _id = id;
}

void TestHex::convert(short int sensorValue[])
{

  udf sensor;
  int counter = 0;
  int length = sizeof(sensor.sensorID)/sizeof(sensor.sensorID[0]);

  int sensorValueLength = sizeof(sensorValue)/sizeof(sensorValue[0]);

  for(int i=0;i< length;i++){
    if (_id == sensor.sensorID[i]) {_id--;break;}
  }

  /*printf("%d %s %d %s %s %s %hd %hd %hd \n",
                    sensor.sensorID[_id],sensor.sensorName[_id],sensor.eventSize[_id],
                    sensor.parseFormat[_id],sensor.axisNames[_id],sensor.scalingFactor[_id],
                    sensorValue[0],sensorValue[1],sensorValue[2]);*/

  char* hex1 = shortToHexadecimal(sensor.sensorID[_id]);
  char* hex2 = charToHexadecimal(sensor.sensorName[_id]);
  char* hex3 = shortToHexadecimal(sensor.eventSize[_id]);
  char* hex4 = charToHexadecimal(sensor.parseFormat[_id]);
  char* hex5 = charToHexadecimal(sensor.axisNames[_id]);
  char* hex6 = charToHexadecimal(sensor.scalingFactor[_id]);
  char* hex7 = charToHexadecimal(sensor.sensorName[_id]);
  char* hex8 = shortToHexadecimal(sensorValue[0]);
  char* hex9 = shortToHexadecimal(sensorValue[1]);
  char* hex10 = shortToHexadecimal(sensorValue[2]);


  Serial.print(hex8);
  Serial.print(" ");
  Serial.println("416363656c65726f6d6574657220284729");

free(hex1);
free(hex2);
free(hex3);
free(hex4);
free(hex5);
free(hex6);
free(hex7);
free(hex8);
free(hex9);
free(hex10);
}

