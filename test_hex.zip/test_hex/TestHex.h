#ifndef TestHex_h
#define TestHex_h

#include "Arduino.h"

class TestHex
{
  public:
    TestHex(int id);
    void convert(short int sensorData[]);
  private:
    int _id;
};

#endif